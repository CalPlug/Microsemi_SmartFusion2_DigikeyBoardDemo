Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release Libero SoC v11.8 SP1 (Version 11.8.1.12)

Date    :    Fri Dec 08 16:23:40 2017
Project :    C:\Users\Hiperwall\Desktop\DigiKeyBoard
